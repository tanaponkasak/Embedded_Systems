/*  copyright 2019 Bert Melis */

#define CATCH_CONFIG_MAIN

#include "Includes/catch.hpp"

TEST_CASE("All test cases reside in other .cpp files (empty)", "[multi-file:1]") {}
